package com.landvibe.summercoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SummerCodingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SummerCodingApplication.class, args);
    }

}
