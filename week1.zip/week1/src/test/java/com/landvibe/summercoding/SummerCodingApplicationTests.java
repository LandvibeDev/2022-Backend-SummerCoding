package com.landvibe.summercoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SummerCodingApplicationTests {

    @Test
    void contextLoads() {
    }

}
